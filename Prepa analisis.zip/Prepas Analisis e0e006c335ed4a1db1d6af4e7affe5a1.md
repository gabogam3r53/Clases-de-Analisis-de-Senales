# Prepas Analisis

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled.jpeg)

Unidad 1 Señales Deterministicas

-Clasificacion de las señales

*operaciones con señales(suma,resta,multiplicacion, traslacion, transpocion,escalamiento en magnitud y tiempo)

-Tipos de funciones mas significativas:

*impulso

*escalon

*rampa

*sigma pulso

-Convolucion

-Usar Matlab y Hathcad

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled.png)

Introduccion:

Lo que aprenderemos en esta materia es el lenguaje por así decirlo para describir señales y sistemas  y un conjunto de herramientas para analizarlos.

Una señal es una funcion que representan una variable o cantidad fisica.

1.1 Señales continuas y discretas

Una señal es una funcion que representan una variable o cantidad fisica.

Las señales pueden describir una amplia variedad de fenomenos fisicos. 

Algunos ejemplos podrian ser 

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%201.png)

Señal continua: Usa la variable x(t) ,f(t), y(t) CUALQUIER NUMERO REAL

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%202.png)

t E REALES

Señal discreta: Usa la variable x[n],y[n] SOLAMENTE  NUMEROS ENTEROS

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%203.png)

x[n]={…0,1,2,3,4…}  EL SUBRRAYADO INDICA LA POSICION DEL ORIGEN y cada numero representa la imagen de la funcion

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%204.png)

La señal de una voz como una funcion del tiempo y la presion atmosferica como una funcion de la altitud son ejemplos de señales continuas.

el indice de bolsa de valores  o el la grafica del dolar es un ejemplo de una señal discreta, otro ejemplo   podria ser cuando yo estoy viendo una poelicula mientras cocino y mi atencion se centra en rebanar lo que estoy cortando y otra parte en las veces que voy mirando el televisor, entonces cada vez que voy mirando el televisor voy armando una señal con los pedazitos de las escenas que logre ver.

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%201.jpeg)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%205.png)

n Entero y Ts es el intervalo de muestreo, que no necesariamente tiene que ser un entero ejemplo intervalo de muestreo cada X[n0.5] muestras

mas adelantes ustedes van a trabajar en micro con los convertidores analogicos a digitales, eso lo que hacen es transformar una señal continua por ejemplo la temperatura, en una señal discreta una cantidad de bits que representan dicha temperatura

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%206.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%207.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%208.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%209.png)

En vez de iniciar en el origen empieza después de un “n tiempo”

Figura 1.10 Inversion del tiempo

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2010.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2011.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2012.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2013.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2014.png)

De esto no voy hablar porque el profesor no lo va evaluar y me importa mas centrarme en darles lo 

que les va evaluar el viernes xd (Señales periodicas) pero si deberian leerlo

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2015.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2016.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2017.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2018.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2019.png)

Leer lo siguiente porque mas adelante lo van usar, en este parcial creo que no

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2020.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2021.png)

Esa parte es importante

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2022.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2023.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2024.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2025.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2026.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2027.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2028.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2029.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2030.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2031.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2032.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2033.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2034.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2035.png)

Esto todavia no xd pero mas adelante si lo explicare

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2036.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2037.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2038.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2039.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2040.png)

CONVOLUCION

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2041.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2042.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2043.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2044.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2045.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2046.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2047.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2048.png)

Ejemplo Convolucion

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2049.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2050.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2051.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2052.png)

![Untitled](Prepas%20Analisis%20e0e006c335ed4a1db1d6af4e7affe5a1/Untitled%2053.png)